﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

///<summary>
///玩家移动类
///</summary>
public class PlayerMotor : MonoBehaviour
{
    private float xSpeed=0;
    private float ySpeed=0;
    public void ChangeSpeed(float m,float energyCount)
    {
        xSpeed += Input.GetAxis("Horizontal") * energyCount / m*Time.deltaTime;
        ySpeed += Input.GetAxis("Vertical") * energyCount / m*Time.deltaTime;
        if (Input.GetKey(KeyCode.Q))
        {
            xSpeed = 0;
            ySpeed = 0;
            this.transform.position = Vector3.zero;
        }
        
        
    }
    public void Translate()
    {
        this.transform.Translate(xSpeed, 0, ySpeed);
    }
}
