﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

///<summary>
///
///</summary>
public class ScoreBallSpawn : MonoBehaviour
{
    public GameObject[] scoreBalls;
    public float fixTimer=2;
    public int total = 400;
    private void Start()
    {
        for(int i=0;i<total ;i++)
        {
            CreateScoreBall();
        }
    }
    private void CreateScoreBall()
    {
        int i = Random.Range(0, 2);
        int y = Random.Range(-500, 500);
        int x = Random.Range(-500, 500);
        Vector3 vect = new Vector3(x, 0.5f, y);
        GameObject go = Instantiate(scoreBalls[i], vect, Quaternion.identity) as GameObject;

    }
}
