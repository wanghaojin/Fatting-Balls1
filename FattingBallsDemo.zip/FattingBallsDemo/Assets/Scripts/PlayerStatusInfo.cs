﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

///<summary>
///玩家定义类
///</summary>
public class PlayerStatusInfo : MonoBehaviour
{
    PlayerStatusInfo statusInfo;
    public float weightGet = 1, energyGet=1;
    public float weight=100, energy = 100;
    private void OnCollisionEnter(Collision collision)
    {
        //检测是否碰到小球
        if (collision.collider.tag == "WeightBall")
        {
            weight += weightGet;
            EatingScoreBall(collision.gameObject);
        }
        if (collision.collider.tag == "EnergyBall")
        {
            energy += energyGet;
            EatingScoreBall(collision.gameObject);
        }

        //检测是否碰到玩家
        if (collision.collider.tag == "Player")
        {
            statusInfo = collision.gameObject.GetComponent<PlayerStatusInfo>();
            if (weight > statusInfo.weight)
            {
                weight += statusInfo.weight;
                energy += statusInfo.energy;                
            }
            if (weight < statusInfo.weight)
            {
                Destroy(this.gameObject);
            }
            
        }       
        this.transform.localScale = Vector3.one *  weight / 100;
    }
    private void EatingScoreBall(GameObject gameObject)
    {
        int y = Random.Range(-500, 500);
        int x = Random.Range(-500, 500);
        Vector3 vect = new Vector3(x, 0.5f, y);
        gameObject.transform.position = vect;
    }
}
