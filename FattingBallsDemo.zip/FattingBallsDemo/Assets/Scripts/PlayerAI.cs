﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

///<summary>
///玩家AI
///</summary>
public class PlayerAI : MonoBehaviour
{
    PlayerStatusInfo statusInfo;
    PlayerMotor motor;
    private void Start()
    {
        statusInfo = this.GetComponent<PlayerStatusInfo>();
        motor = this.GetComponent<PlayerMotor>();

    }
    private void Update()
    {
        motor.ChangeSpeed(statusInfo.weight,statusInfo.energy);        
        motor.Translate();
    }    
    
    
}